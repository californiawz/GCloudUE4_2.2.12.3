//
//  MSDKPIXQQ.h
//  MSDKPIXQQ
//
//  Created by xiaoxuzheng on 11/22/21.
//  Copyright © 2021 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MSDKPIXQQ_Version_String "5.30.100.2609"
#define MSDKPIXQQ_Version_Int 53100
