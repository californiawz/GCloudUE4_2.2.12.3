//
//  QQApiInterface+Full.h
//  QQApi
//
//  Created by cocozzhang on 2019/7/25.
//

#ifndef QQApiInterface_Full_h
#define QQApiInterface_Full_h

@interface QQApiInterface (Full)


@end

#endif /* QQApiInterface_Full_h */
