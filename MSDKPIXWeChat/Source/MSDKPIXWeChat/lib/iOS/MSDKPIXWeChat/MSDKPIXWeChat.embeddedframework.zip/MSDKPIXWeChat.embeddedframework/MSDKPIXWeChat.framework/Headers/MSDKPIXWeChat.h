//
//  MSDKPIXWeChat.h
//  MSDKPIXWeChat
//
//  Created by xiaoxuzheng on 11/18/21.
//  Copyright © 2021 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MSDKPIXWeChat_Version_String "5.30.100.2609"
#define MSDKPIXWeChat_Version_Int 53100



