//
//  GPixUI.h
//  PixUI
//  PixUI API
//
//  Created by kiddpeng on 2022/6/29.
//  Copyright © 2022年 pixui. All rights reserved.
//


#ifndef GPixUI_h
#define GPixUI_h

#include "GCloudPluginManager/PluginBase/PluginBase.h"

#ifdef ANDROID
#include <android/log.h>
#endif

GCLOUD_PLUGIN_NAMESPACE

class GPixUI : public GCloud::Plugin::Singleton<GPixUI> , public GCloud::Plugin::PluginBase
{
public:
    
    virtual const char* GetName() const
    {
        return "GPixUI";
    };
    virtual const char* GetVersion() const
    {
        return "1.0.000.1108";
    };
    
public:
    virtual void OnStartup(GCloud::Plugin::IServiceRegister* serviceRegister)
    {
        
#ifdef ANDROID
        __android_log_print(ANDROID_LOG_INFO, "", "GPixUI OnStartup");
#endif
        
#ifdef __APPLE__
        NSLog(@"GPixUI OnStartup");
#endif
        
        if (serviceRegister) {
            serviceRegister->Register("GPixUIService");
        }
    };
    virtual void OnPostStartup() {};
    
    virtual void OnPreShutdown() {};
    virtual void OnShutdown() {};
    
public:
    virtual GCloud::Plugin::IPluginService* GetServiceByName(const char* serviceName);
};

GCLOUD_PLUGIN_NAMESPACE_END

#endif /* GPixUI_h */
