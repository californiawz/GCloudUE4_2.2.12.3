//
//  PxExtObjc_Ios_Framework.h
//  PxExtObjc_Ios_Framework
//
//  Created by tianzelei(雷虎) on 2021/6/7.
//

#import <Foundation/Foundation.h>

//! Project version number for PxExtObjc_Ios_Framework.
FOUNDATION_EXPORT double PxExtObjc_Ios_FrameworkVersionNumber;

//! Project version string for PxExtObjc_Ios_Framework.
FOUNDATION_EXPORT const unsigned char PxExtObjc_Ios_FrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PxExtObjc_Ios_Framework/PublicHeader.h>


