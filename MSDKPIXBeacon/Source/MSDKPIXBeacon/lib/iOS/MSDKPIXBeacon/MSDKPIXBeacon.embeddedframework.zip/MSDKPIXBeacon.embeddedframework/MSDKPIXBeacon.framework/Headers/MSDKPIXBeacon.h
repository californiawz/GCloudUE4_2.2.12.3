//
//  MSDKPIXBeacon.h
//  MSDKPIXBeacon
//
//  Created by godmanzheng on 2021/12/27.
//  Copyright © 2021 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>


#define MSDKPIXBeacon_Version_String "5.30.100.2609"
#define MSDKPIXBeacon_Version_Int 53100
