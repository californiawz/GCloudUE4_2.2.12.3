//
//  QimeiSDK.h
//  QimeiSDK
//
//  Created by pariszhao on 2020/10/9.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <QimeiSDK/QimeiService.h>
#import <QimeiSDK/QimeiContent.h>
#import <QimeiSDK/QimeiServiceConfig.h>

