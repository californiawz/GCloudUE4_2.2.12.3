//
//  BeaconId.h
//  BeaconId
//
//  Created by jackhuali on 2020/7/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#ifndef BeaconId_h
#define BeaconId_h

#import <BeaconId/BeaconIdInfoCollector.h>


#endif /* BeaconId_h */
#define BEACONID_SDK_VERSION @"1.0.7"
