//
//  MSDKPIXSystem.h
//  MSDKPIXSystem
//
//  Created by jatzhao on 2022/7/28.
//  Copyright © 2022 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MSDKPIXSystem_Version_String "5.30.100.2609"
#define MSDKPIXSystem_Version_Int 53100
