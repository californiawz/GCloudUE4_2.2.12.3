//
//  XGMTACloud.h
//  XGMTACloud
//
//  Created by uwei on 2019/7/4.
//  Copyright © 2019 TEG of Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for XGMTACloud.
FOUNDATION_EXPORT double XGMTACloudVersionNumber;

//! Project version string for XGMTACloud.
FOUNDATION_EXPORT const unsigned char XGMTACloudVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XGMTACloud/PublicHeader.h>

#import "MTA.h"
#import "MTAConfig.h"
