//
//  MSDKPIXXG.h
//  MSDKPIXXG
//
//  Created by xiaoxuzheng on 8/10/22.
//  Copyright © 2022 MSDK. All rights reserved.
//

#ifndef MSDKPIXXG_h
#define MSDKPIXXG_h

#define MSDKPIXXG_Version_String "5.30.100.2609"
#define MSDKPIXXG_Version_Int 53100

#endif /* MSDKPIXXG_h */
