//
//  MSDKPIXWebView.h
//  MSDKPIXWebView
//
//  Created by xiaoxuzheng on 12/26/21.
//  Copyright © 2021 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MSDKPIXWebView_Version_String "5.30.100.2609"
#define MSDKPIXWebView_Version_Int 53100

