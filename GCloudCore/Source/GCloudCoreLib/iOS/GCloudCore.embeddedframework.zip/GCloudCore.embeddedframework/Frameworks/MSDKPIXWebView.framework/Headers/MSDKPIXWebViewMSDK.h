//
//  MSDKPIXWebViewMSDK.h
//  MSDKPIXWebView
//
//  Created by xiaoxuzheng on 12/28/21.
//  Copyright © 2021 MSDK. All rights reserved.
//

#ifndef MSDKPIXWebViewMSDK_h
#define MSDKPIXWebViewMSDK_h

#import <Foundation/Foundation.h>
#import "MSDKPIXWebViewDelegate.h"
#import "MSDKPIXWebViewPluginDelegate.h"
#import <UIKit/UIKit.h>
#import "MSDKPIXWebViewProtocol.h"
#import "MSDKPIXWebViewDefine.h"

/**
 wenview MSDK
 */
@interface MSDKPIXWebViewMSDK : NSObject <MSDKPIXWebViewDelegate, MSDKPIXWebViewPluginDelegate>

//activated
@property (nonatomic, assign) BOOL activated;

//custom window
@property (nonatomic, strong) UIWindow * customWindow;

//protocol
@property(nonatomic, strong) id<MSDKPIXWebViewProtocol> protocol;

+ (instancetype)sharedInstance;

-(void) setDelegate: (id<MSDKPIXWebViewProtocol>) pro ;

- (void)handleFriendRequest:(MSDKPIXWebViewFriendReqInfo *)reqInfo;

- (void)callJS:(NSString *)parametersJSON;

- (void)shareRet:(NSString *)json;

- (int) getScreenType;

@end

#endif /* MSDKPIXWebViewMSDK_h */
