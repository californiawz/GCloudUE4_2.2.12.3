//
//  MSDKPIXLBS.h
//  MSDKPIXLBS
//
//  Created by xiaoxuzheng on 1/21/22.
//  Copyright © 2022 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MSDKPIXLBS_Version_String "5.30.100.2609"
#define MSDKPIXLBS_Version_Int 53100
