//
//  GPixUIService.h
//  Pixui
//  Pixui API
//
//  Created by kiddpeng on 2022/6/29.
//  Copyright © 2022年 pixui. All rights reserved.
//

#ifndef GPixUIService_h
#define GPixUIService_h

#include "GCloudPluginManager/PluginBase/PluginBase.h"
#include "IGPixUIService.h"

GCLOUD_PLUGIN_NAMESPACE

class GPixUIService : public IGPixUIService
{
private:
    GPixUIService() { mGCloudLogger = NULL; mGCloudCrosCurlFuncs = NULL; }
    ~GPixUIService(){}

private:
    GCloud::ILogger *mGCloudLogger;
    GCloud::Plugin::CurlFuncs *mGCloudCrosCurlFuncs;
    
public:
    static GPixUIService* GetInstance();
    void ReleaseInstance();
    
    virtual const char* GetName() const
    {
        return "GPixUIService";
    }
    virtual const char* GetPluginName() const
    {
        return "GPixUI";
    }
    
public:
    GCloud::ILogger *GetGCloudLogger();
    GCloud::Plugin::CurlFuncs *GetGCloudCrosCurl();

#if defined (ANDROID)
    int StartUp(jobject activity);
    bool IsStartUp();
    const char *GetPixUIVersion();
    jobject CreatePxView(jobject activity, int witdh, int height);
    jobject CreatePxViewHD(jobject activity, int witdh, int height);
    void AddView(jobject container, jobject view);
    void RemoveView(jobject container, jobject view);
    int PageLoadUrl(jobject view, const char* url, bool isHD);
    int ShutDown();
#elif defined (__APPLE__)
    const char *GetPixUIVersion();
    bool IsStartUp();
    int StartUp(NSString *agent);
    PxViewHD* CreatePxViewHD(CGRect rect);
    PxView* CreatePxView(CGRect rect);
    int PageLoadUrl(PxViewHD* view, NSString *url);
    int PageLoadUrl(PxView* view, NSString *url);
    int ShutDown();
#endif
};

GCLOUD_PLUGIN_NAMESPACE_END

#endif /* GPixUIService_h */
