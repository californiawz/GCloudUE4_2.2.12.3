//
//  MSDKPopup.h
//  MSDKPopup
//
//  Created by MikeFu on 2022/5/9.
//  Copyright © 2022 company. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MSDKPopupDefine.h"

#define MSDKPopup_Version_String  "1.0.0"
#define MSDKPopup_Version_Int 100

@interface MSDKPopup : NSObject

+ (void)showPolicy:(MSDKPopupComplete)complete;

+ (void)startPopup:(NSString*)popUrl gameID:(NSString *)gameID gameKey:(NSString *)gameKey;

+ (BOOL)havePopup:(MSDKPopupSceneType)sceneType;

+ (void)showPopup:(NSString *)scene sceneType:(MSDKPopupSceneType)sceneType complete:(MSDKPopupComplete)complete;

+ (void)setChannelID:(int)channelID openID:(NSString *)openID token:(NSString *)token jwtToken:(NSString *)jwtToken;

@end
