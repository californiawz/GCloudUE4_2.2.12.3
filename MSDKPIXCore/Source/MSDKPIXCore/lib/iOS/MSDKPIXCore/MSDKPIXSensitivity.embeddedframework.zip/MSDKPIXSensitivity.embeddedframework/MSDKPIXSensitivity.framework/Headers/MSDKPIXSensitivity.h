//
//  MSDKPIXSensitivity.h
//  MSDKPIXSensitivity
//
//  Created by jatz on 2022/8/22.
//  Copyright © 2022 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MSDKPIXSensitivity_Version_String "5.30.100.2614"
#define MSDKPIXSensitivity_Version_Int 53100
#define GCLOUD_VERSION_MSDK_SENSITIVITY "GCLOUD_VERSION_MSDK_SENSITIVITY_5.12.000"
