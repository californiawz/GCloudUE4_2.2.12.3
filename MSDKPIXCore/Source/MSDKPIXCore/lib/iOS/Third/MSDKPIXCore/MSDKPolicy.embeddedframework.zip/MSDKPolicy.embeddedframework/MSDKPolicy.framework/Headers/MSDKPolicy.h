//
//  MSDKPolicy.h
//  MSDKPopup
//
//  Created by MikeFu on 2022/7/5.
//  Copyright © 2022 company. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MSDKPopupDefine.h"

typedef void(^MSDKPopupLifecycleEventCallback)(id param);

@interface MSDKPolicy : NSObject

+ (void)showPolicy:(id)param complete:(MSDKPolicyComplete)complete;

+ (BOOL)isPolicyComplete;

+ (void)registerLifecycleEvent:(MSDKPopupLifecycleEventCallback)block;

@end
