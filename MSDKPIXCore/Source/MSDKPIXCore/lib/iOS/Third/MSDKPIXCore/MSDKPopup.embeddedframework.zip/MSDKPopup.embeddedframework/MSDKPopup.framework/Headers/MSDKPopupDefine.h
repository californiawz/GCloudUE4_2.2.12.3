//
//  MSDKPopupDefine.h
//  MSDKPopup
//
//  Created by MikeFu on 2022/5/11.
//  Copyright © 2022 company. All rights reserved.
//

#ifndef MSDKPopupDefine_h
#define MSDKPopupDefine_h
#define MSDKPolicy_Reject @"MSDKPolicy_Reject"
typedef enum : NSUInteger {
    MSDKPopupSceneType_Default,
    MSDKPopupSceneType_Launch,
    MSDKPopupSceneType_Before_Platform_Login,
    MSDKPopupSceneType_After_Platform_Login,
    MSDKPopupSceneType_Before_MSDK_Login_Callback,
    MSDKPopupSceneType_Before_MSDK_Auto_Login_Callback,
} MSDKPopupSceneType;

typedef enum : int {
    MSDKPopupActionType_Error = -1,
    MSDKPopupActionType_Skip = 0,
    MSDKPopupActionType_Commit = 1,
    MSDKPopupActionType_Cancel = 2,
} MSDKPopupActionType;

typedef void(^MSDKPolicyComplete)(id param);
typedef void(^MSDKPopupComplete)(int action, NSString * __nonnull msg);



//UI Layout
typedef enum : NSUInteger {
    MSDKLayout_Fill_Super_View,
    MSDKLayout_Inset_Super_View,
} MSDKLayoutType;

#endif /* MSDKPopupDefine_h */
