//
//  MSDKPIXTDM.h
//  MSDKPIXTDM
//
//  Created by godmanzheng on 2022/1/12.
//  Copyright © 2022 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>


#define MSDKPIXTDM_Version_String "5.30.100.2609"
#define MSDKPIXTDM_Version_Int 53100
