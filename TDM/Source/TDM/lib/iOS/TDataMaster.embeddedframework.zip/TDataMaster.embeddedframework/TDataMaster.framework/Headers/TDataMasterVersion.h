#ifndef TDataMasterVersion_h
#define TDataMasterVersion_h

#define TDataMaster_Version_String "1.28.005.2077"

#define TDataMaster_GCloud_Version_String "GCLOUD_VERSION_TDM_1.28.005.2077"

#endif /* TDataMasterVersion_h */